# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Socialpro::Application.config.secret_token = '548ce11f69bb22db4e8ed9d3f7af963335f4cc136031d0d035fd2caf6cfa2f60c9ec1244582137f6ec0f1f488e14d262c32a5943b854522e55aa77e6d053d2e7'
