require 'twitter'
$client = Twitter::REST::Client.new do |config|
  config.consumer_key        = "N9TmNOr4NS6uJI3DytIYbDQ57"
  config.consumer_secret     = "CEi2gYwGJ77Z9gfSGSEQFJSTWw8v55qw3S229iibYkC01fSrkv"
  config.access_token        = "1527877718-2dhDlqDZvi2E093qXbaSruNReu7Xha7PsIASFoB"
  config.access_token_secret = "8qOS2yVRa1VZv8fUX8I8rwjgW6EWc8cu3qBqPYUIsa8Zx"
end
